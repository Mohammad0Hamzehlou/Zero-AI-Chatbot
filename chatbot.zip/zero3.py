import sys
import os
import pygame
import cv2
import queue
import sounddevice as sd
import vosk
import json
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QLabel, QHBoxLayout
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QTextCursor, QColor, QFont, QPixmap, QIcon
from textblob import TextBlob
import ollama
from gtts import gTTS  # استفاده از gTTS برای تبدیل متن به گفتار
import time
import playsound  # برای پخش فایل صوتی

# Avatar class for Pygame visualization
class Avatar:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Zero Avatar")
        self.running = True
        self.expression = (0, 0, 255)  # Default blue (neutral)

    def update_expression(self, sentiment):
        if sentiment == "happy":
            self.expression = (0, 128, 0)  # Green
        elif sentiment == "sad":
            self.expression = (255, 0, 0)  # Red
        else:
            self.expression = (0, 0, 255)  # Blue
        self.draw()

    def draw(self):
        self.screen.fill((255, 255, 255))
        pygame.draw.circle(self.screen, self.expression, (150, 150), 100)
        pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
        pygame.quit()

# Sentiment analysis function
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:
        return "happy", QColor(0, 128, 0)
    elif analysis.sentiment.polarity < -0.2:
        return "sad", QColor(255, 0, 0)
    else:
        return "neutral", QColor(0, 0, 255)

# Generate response using Mistral
def generate_response(user_input, sentiment):
    prompt = f"The user is feeling {sentiment} and said: {user_input}\nRespond in a friendly manner:"
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# Text to speech function using gTTS
def text_to_speech(text):
    tts = gTTS(text=text, lang='en')
    tts.save("response.mp3")
    playsound.playsound("response.mp3")

# Thread for capturing image
class CaptureImageThread(QThread):
    image_captured = pyqtSignal(str)

    def run(self):
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.image_captured.emit("Error: Could not open camera.")
            return
        ret, frame = cap.read()
        if ret:
            image_path = "captured_image.png"
            cv2.imwrite(image_path, frame)
            self.image_captured.emit(image_path)
        cap.release()

# Thread for speech recognition (Offline using Vosk)
class SpeechRecognitionThread(QThread):
    speech_text = pyqtSignal(str)

    def run(self):
        # مسیر مدل زبانی Vosk
        model_path = r"C:\Users\Mohamad\Desktop\chatbot\vosk-model-small-en-us-0.15"  
        if not os.path.exists(model_path):
            self.speech_text.emit("Error: Vosk model not found.")
            return

        # تنظیمات Vosk
        model = vosk.Model(model_path)
        samplerate = 16000
        device = 1  # شماره دستگاه میکروفون (با دستور sounddevice.query_devices() می‌توانید بررسی کنید)

        q = queue.Queue()

        def callback(indata, frames, time, status):
            if status:
                print(status, file=sys.stderr)
            q.put(bytes(indata))

        try:
            with sd.RawInputStream(samplerate=samplerate, blocksize=8000, device=device,
                                  dtype='int16', channels=1, callback=callback):
                rec = vosk.KaldiRecognizer(model, samplerate)
                print("Listening...")
                while True:
                    data = q.get()
                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result())
                        self.speech_text.emit(result['text'])
                        break
        except Exception as e:
            self.speech_text.emit(f"Error: {str(e)}")

# Main chatbot GUI
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.avatar = Avatar()
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.avatar.draw)
        self.timer.start(1000)

    def initUI(self):
        self.setWindowTitle("Zero - Your Wise Companion")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("""
            QWidget {
                background-color: #2E3440;
                color: #D8DEE9;
            }
            QTextEdit {
                background-color: #3B4252;
                color: #ECEFF4;
                border: 1px solid #4C566A;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QLineEdit {
                background-color: #3B4252;
                color: #ECEFF4;
                border: 1px solid #4C566A;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton {
                background-color: #5E81AC;
                color: #ECEFF4;
                border: none;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #81A1C1;
            }
        """)

        layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)

        input_layout = QHBoxLayout()
        self.user_input = QLineEdit()
        self.user_input.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.user_input)

        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        input_layout.addWidget(send_button)

        voice_button = QPushButton("🎤")
        voice_button.clicked.connect(self.start_voice_input)
        input_layout.addWidget(voice_button)

        capture_button = QPushButton("📷")
        capture_button.clicked.connect(self.capture_image)
        input_layout.addWidget(capture_button)

        layout.addLayout(input_layout)
        self.setLayout(layout)

    def send_message(self):
        user_message = self.user_input.text()
        if not user_message.strip():
            return
        sentiment, color = analyze_sentiment(user_message)
        self.chat_display.append(f"You: {user_message}")
        self.chat_display.setTextColor(color)
        self.user_input.clear()

        # Simulate typing delay
        QTimer.singleShot(1000, lambda: self.show_response(user_message, sentiment))

    def show_response(self, user_message, sentiment):
        response = generate_response(user_message, sentiment)
        self.chat_display.append(f"Zero: {response}\n")
        text_to_speech(response)  # استفاده از gTTS برای تبدیل متن به گفتار
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        self.avatar.update_expression(sentiment)

    def start_voice_input(self):
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.start()

    def handle_voice_input(self, text):
        self.user_input.setText(text)
        self.send_message()

    def capture_image(self):
        self.capture_thread = CaptureImageThread()
        self.capture_thread.image_captured.connect(self.handle_captured_image)
        self.capture_thread.start()

    def handle_captured_image(self, image_path):
        self.chat_display.append(f"Image captured: {image_path}\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    chatbot = ChatbotGUI()
    chatbot.show()
    pygame_thread = pygame.threads.Thread(target=chatbot.avatar.run)
    pygame_thread.start()
    sys.exit(app.exec())