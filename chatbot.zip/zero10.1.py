import sys
import os
import pygame
import cv2
import queue
import sounddevice as sd
import vosk
import json
import cadquery as cq
from cadquery import exporters
import ollama
import numpy as np
from scipy.integrate import solve_ivp
from scipy.fft import fft
from sympy import symbols, Function, laplace_transform
import subprocess
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QHBoxLayout
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QTextCursor, QColor
from textblob import TextBlob
from gtts import gTTS
import pyttsx3
import time
import random

# مقداردهی اولیه
pygame.mixer.init()
engine = pyttsx3.init()

# کلاس آواتار
class Avatar:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Zero Avatar")
        self.running = True
        self.expression = (0, 0, 255)  # Default blue (neutral)

    def update_expression(self, emotion):
        if emotion == "happy": self.expression = (0, 128, 0)  # Green
        elif emotion == "sad": self.expression = (255, 0, 0)  # Red
        elif emotion == "angry": self.expression = (128, 0, 0)  # Dark Red
        elif emotion == "surprised": self.expression = (255, 165, 0)  # Orange
        elif emotion == "fearful": self.expression = (128, 0, 128)  # Purple
        else: self.expression = (0, 0, 255)  # Blue
        self.draw()

    def draw(self):
        if self.running and pygame.display.get_init():
            self.screen.fill((255, 255, 255))
            pygame.draw.circle(self.screen, self.expression, (150, 150), 100)
            pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
        pygame.quit()

# سیستم احساسات
class EmotionSystem:
    def __init__(self):
        self.emotions = {"happy": 0, "sad": 0, "angry": 0, "surprised": 0, "fearful": 0, "neutral": 100}
        self.current_emotion = "neutral"

    def update_emotion(self, sentiment):
        if sentiment == "happy":
            self.emotions["happy"] += 10
            self.emotions["sad"] -= 5
            self.emotions["angry"] -= 5
        elif sentiment == "sad":
            self.emotions["sad"] += 10
            self.emotions["happy"] -= 5
            self.emotions["angry"] += 5
        elif sentiment == "angry":
            self.emotions["angry"] += 10
            self.emotions["happy"] -= 5
            self.emotions["sad"] += 5
        else:
            self.emotions["neutral"] += 5
        
        for emotion in self.emotions:
            self.emotions[emotion] = max(0, min(100, self.emotions[emotion]))
        self.current_emotion = max(self.emotions, key=self.emotions.get)

    def get_emotion_response(self):
        if self.current_emotion == "happy": return random.choice(["I'm happy! 😊", "Feeling great! 🌟"])
        elif self.current_emotion == "sad": return random.choice(["I'm feeling down. 😢", "Not my best day..."])
        elif self.current_emotion == "angry": return random.choice(["I'm upset! 😠", "This is frustrating."])
        elif self.current_emotion == "surprised": return random.choice(["Wow! 😮", "That's surprising!"])
        elif self.current_emotion == "fearful": return random.choice(["I'm scared! 😨", "This is worrying..."])
        else: return random.choice(["I'm okay. 🤔", "Feeling neutral."])

# ماشین‌حساب مهندسی مکانیک (بهبودیافته برای 3D با جزئیات بالا)
class MechanicalEngineeringCalculator:
    def design_mechanism(self, user_input):
        # پارامترهای پیش‌فرض برای مواد و تلرانس‌ها
        default_material = "Aluminum"
        default_tolerance = 0.01  # میلی‌متر

        # درخواست از مدل برای تولید پارامترهای طراحی
        prompt = (
            f"The user requested: {user_input}\n"
            "Return a Python dictionary of key design parameters for a mechanical component. "
            "Include dimensions (e.g., width, height, depth, reach, joints, diameter, length), "
            "material (e.g., Aluminum, Steel), tolerances (in mm), and connection types (e.g., bolts, welds). "
            "Use reasonable defaults if specifics are missing. Ensure all numeric values are numbers (not strings). "
            "Examples: {{'width': 1, 'height': 1, 'depth': 1, 'material': 'Aluminum', 'tolerance': 0.01, 'connection': 'bolts'}} for a box, "
            "{{'reach': 1, 'joints': 3, 'material': 'Steel', 'tolerance': 0.02, 'connection': 'welds'}} for a robotic arm, "
            "{{'diameter': 0.1, 'length': 1, 'material': 'Steel', 'tolerance': 0.01, 'connection': 'pins'}} for a shaft.\n"
            "Do not include any explanatory text, just the dictionary."
        )
        response = ollama.generate(model="mistral", prompt=prompt)
        design_data = eval(response['response'])

        # تبدیل مقادیر رشته‌ای به عدد
        for key in design_data:
            if isinstance(design_data[key], str) and design_data[key].replace(".", "").isdigit():
                design_data[key] = float(design_data[key])

        # اضافه کردن مقادیر پیش‌فرض اگه وجود نداشته باشن
        design_data.setdefault('material', default_material)
        design_data.setdefault('tolerance', default_tolerance)
        design_data.setdefault('connection', 'bolts')

        return design_data

    def generate_step_model(self, design_data, filename="mechanism.step", stl_filename="mechanism.stl", render_filename="mechanism_render.png"):
        result = cq.Workplane("XY")
        bom = []  # لیست قطعات (Bill of Materials)

        if "width" in design_data:  # طراحی باکس (مثلاً بدنه CNC)
            width = design_data.get("width", 1)
            height = design_data.get("height", 1)
            depth = design_data.get("depth", 1)
            result = result.box(width, height, depth)
            bom.append({"part": "Body", "width": width, "height": height, "depth": depth, 
                        "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7)})  # نقره‌ای

        elif "reach" in design_data:  # طراحی بازوی رباتیک
            reach = design_data.get("reach", 1)
            joints = design_data.get("joints", 3)
            segment_length = reach / joints
            gripper_size = design_data.get("gripper_size", 0.1)  # اندازه گریپر

            # پایه بازو
            base = cq.Workplane("XY").box(segment_length * 0.5, segment_length * 0.5, 0.1).fillet(0.01)
            bom.append({"part": "Base", "width": segment_length * 0.5, "height": segment_length * 0.5, "depth": 0.1, 
                        "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7)})  # نقره‌ای

            # بازوها با مفاصل
            arm = base
            joint_radius = 0.03  # شعاع مفاصل
            for i in range(joints):
                # بازو
                segment = cq.Workplane("XY").box(segment_length, 0.05, 0.05).translate((segment_length * i + segment_length/2, 0, 0.1)).fillet(0.005)
                arm = arm.union(segment)
                bom.append({"part": f"Arm Segment {i+1}", "length": segment_length, "width": 0.05, "height": 0.05, 
                            "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7)})
                # مفصل (به صورت استوانه با پین)
                joint = cq.Workplane("XY").circle(joint_radius).extrude(0.06).translate((segment_length * (i + 1), 0, 0.1))
                pin = cq.Workplane("XY").circle(0.01).extrude(0.08).translate((segment_length * (i + 1), 0, 0.1))
                joint = joint.union(pin)
                arm = arm.union(joint)
                bom.append({"part": f"Joint {i+1}", "diameter": joint_radius * 2, "height": 0.06, 
                            "material": "Steel", "tolerance": 0.005, "color": (0.5, 0.5, 0.5)})  # خاکستری تیره
                bom.append({"part": f"Pin {i+1}", "diameter": 0.02, "height": 0.08, 
                            "material": "Steel", "tolerance": 0.005, "color": (0.3, 0.3, 0.3)})  # خاکستری

            # موتورها (برای هر مفصل)
            for i in range(joints):
                motor = cq.Workplane("XY").box(0.06, 0.06, 0.04).translate((segment_length * (i + 1), 0.08, 0.1))
                arm = arm.union(motor)
                bom.append({"part": f"Servo Motor {i+1}", "width": 0.06, "height": 0.06, "depth": 0.04, 
                            "material": "Plastic", "tolerance": 0.02, "color": (0.1, 0.1, 0.1)})  # مشکی

            # گریپر با انگشت‌های متحرک
            gripper_base = cq.Workplane("XY").box(gripper_size, gripper_size * 0.5, gripper_size * 0.5).translate((segment_length * joints + gripper_size/2, 0, 0.1)).fillet(0.005)
            arm = arm.union(gripper_base)
            bom.append({"part": "Gripper Base", "width": gripper_size, "height": gripper_size * 0.5, "depth": gripper_size * 0.5, 
                        "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7)})
            # انگشت‌های گریپر
            finger1 = cq.Workplane("XY").box(gripper_size * 0.2, gripper_size * 0.1, gripper_size * 0.6).translate((segment_length * joints + gripper_size/2, gripper_size * 0.3, 0.1)).fillet(0.005)
            finger2 = cq.Workplane("XY").box(gripper_size * 0.2, gripper_size * 0.1, gripper_size * 0.6).translate((segment_length * joints + gripper_size/2, -gripper_size * 0.3, 0.1)).fillet(0.005)
            arm = arm.union(finger1).union(finger2)
            bom.append({"part": "Gripper Finger", "width": gripper_size * 0.2, "height": gripper_size * 0.1, "depth": gripper_size * 0.6, 
                        "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7), "quantity": 2})

            # کابل‌ها (به صورت استوانه‌های نازک)
            cable = cq.Workplane("XY").circle(0.01).extrude(reach).translate((0, 0.1, 0.1))
            arm = arm.union(cable)
            bom.append({"part": "Cable", "diameter": 0.02, "length": reach, "material": "Rubber", "tolerance": 0.02, "color": (0.1, 0.1, 0.1)})  # مشکی

            # سنسور (برای گریپر)
            sensor = cq.Workplane("XY").box(0.03, 0.03, 0.02).translate((segment_length * joints + gripper_size/2, 0, 0.2))
            arm = arm.union(sensor)
            bom.append({"part": "Proximity Sensor", "width": 0.03, "height": 0.03, "depth": 0.02, 
                        "material": "Plastic", "tolerance": 0.02, "color": (0.2, 0.2, 0.2)})  # خاکستری تیره

            result = arm

        elif "diameter" in design_data:  # طراحی شفت یا محور
            diameter = design_data.get("diameter", 0.1)
            length = design_data.get("length", 1)
            result = result.circle(diameter / 2).extrude(length)
            bom.append({"part": "Shaft", "diameter": diameter, "length": length, 
                        "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7)})

        else:  # پیش‌فرض
            result = result.box(1, 1, 1)
            bom.append({"part": "Default Box", "width": 1, "height": 1, "depth": 1, 
                        "material": design_data['material'], "tolerance": design_data['tolerance'], "color": (0.7, 0.7, 0.7)})

        # اضافه کردن اتصالات
        if design_data['connection'] == 'bolts':
            # فرض می‌کنیم 4 پیچ روی پایه اضافه می‌کنیم
            if "reach" in design_data:
                result = result.faces(">Z").workplane().pushPoints([(-0.1, -0.1), (-0.1, 0.1), (0.1, -0.1), (0.1, 0.1)]).hole(0.01)
                # مدل پیچ‌ها با رزوه
                bolt = cq.Workplane("XY").circle(0.01/2).extrude(0.03).translate((0, 0, 0.1))
                for pos in [(-0.1, -0.1), (-0.1, 0.1), (0.1, -0.1), (0.1, 0.1)]:
                    bolt_translated = bolt.translate((pos[0], pos[1], 0))
                    result = result.union(bolt_translated)
                bom.append({"part": "Bolt", "diameter": 0.01, "height": 0.03, "quantity": 4, "material": "Steel", "tolerance": 0.005, "color": (0.3, 0.3, 0.3)})

        # ذخیره فایل STEP
        exporters.export(result, filename, cq.exporters.ExportTypes.STEP)

        # ذخیره فایل STL برای رندر در Blender
        exporters.export(result, stl_filename, cq.exporters.ExportTypes.STL)

        # تولید رندر با Blender
        render_result = self.render_with_blender(stl_filename, render_filename, bom)

        # تولید گزارش BOM
        bom_report = "Bill of Materials:\n"
        for item in bom:
            bom_report += f"{item}\n"

        return f"فایل STEP در '{filename}' ذخیره شد.\nفایل STL در '{stl_filename}' ذخیره شد.\nرندر با کیفیت بالا در '{render_filename}' ذخیره شد.\n{bom_report}"

    def render_with_blender(self, stl_filename, render_filename, bom):
        # اسکریپت Blender برای رندر
        blender_script = """
import bpy
import os

# پاک کردن صحنه پیش‌فرض
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()

# وارد کردن فایل STL
bpy.ops.import_mesh.stl(filepath="{}")

# تنظیم مواد و رنگ‌ها برای هر قطعه
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        mat = bpy.data.materials.new(name=obj.name + "_material")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = next(node for node in nodes if node.type == 'BSDF_PRINCIPLED')
        # پیدا کردن رنگ از BOM
        color = (0.7, 0.7, 0.7, 1)  # پیش‌فرض نقره‌ای
        for item in {}
        if item['part'] in obj.name:
            color = (*item['color'], 1)
            break
        principled.inputs['Base Color'].default_value = color
        obj.data.materials.append(mat)

# تنظیم دوربین
bpy.ops.object.camera_add(location=(3, -3, 2))
camera = bpy.context.object
camera.rotation_euler = (1.0472, 0, 0.7854)  # زاویه 60 درجه و 45 درجه
bpy.context.scene.camera = camera

# تنظیم نور
bpy.ops.object.light_add(type='SUN', location=(5, 5, 5))
light = bpy.context.object
light.data.energy = 5

# تنظیم رندر
bpy.context.scene.render.engine = 'CYCLES'
bpy.context.scene.render.resolution_x = 1920
bpy.context.scene.render.resolution_y = 1080
bpy.context.scene.render.filepath = "{}"
bpy.ops.render.render(write_still=True)

# خروج
bpy.ops.wm.quit_blender()
""".format(os.path.abspath(stl_filename), bom, os.path.abspath(render_filename))

        # ذخیره اسکریپت Blender
        blender_script_path = "render_script.py"
        with open(blender_script_path, "w") as f:
            f.write(blender_script)

        # اجرای Blender برای رندر
        try:
            blender_path = "blender"  # فرض می‌کنیم blender توی PATH هست
            subprocess.run([blender_path, "-b", "-P", blender_script_path], check=True)
            return f"رندر با موفقیت در '{render_filename}' ذخیره شد."
        except Exception as e:
            return f"خطا در رندر با Blender: {str(e)}"

    def simulate_motion(self, design_data):
        # شبیه‌سازی ساده حرکت (بدون pybullet)
        if "reach" in design_data:
            joints = design_data.get("joints", 3)
            reach = design_data.get("reach", 1)
            segment_length = reach / joints
            simulation_report = "شبیه‌سازی حرکت بازوی رباتیک:\n"
            for i in range(joints):
                simulation_report += f"مفصل {i+1}: چرخش 45 درجه، جابجایی {segment_length} متر\n"
            simulation_report += "گریپر: باز و بسته شدن با زاویه 30 درجه\n"
            return simulation_report
        return "شبیه‌سازی برای این طراحی پشتیبانی نمی‌شود."

# تابع تولید کد برنامه‌نویسی
def generate_programming_code(user_input):
    prompt = (
        f"The user requested: {user_input}\n"
        "Generate accurate, complete, and well-structured code in the specified programming language. "
        "If no language is specified, ask the user to clarify. "
        "Include comments for clarity, ensure the code is ready to run, and handle all edge cases."
    )
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# تابع تست و دیباگ کد
def test_and_debug_code(code, language, filename):
    save_code_to_file(code, filename)
    compilers = {
        "python": ["python", filename],
        "go": ["go", "run", filename],
        "c": ["gcc", filename, "-o", "test_output"],
        "cpp": ["g++", filename, "-o", "test_output"],
        "java": ["javac", filename],
        "javascript": ["node", filename],
        "php": ["php", filename],
        "ruby": ["ruby", filename],
    }
    if language not in compilers:
        return f"تست برای {language} پشتیبانی نمی‌شود."
    try:
        result = subprocess.run(compilers[language], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            if language in ["c", "cpp"]:
                exec_result = subprocess.run("./test_output" if os.name != "nt" else "test_output.exe", 
                                            capture_output=True, text=True, timeout=10)
                return f"کد با موفقیت اجرا شد:\n{exec_result.stdout}"
            return f"کد با موفقیت اجرا شد:\n{result.stdout}"
        else:
            error = result.stderr
            debug_prompt = (
                f"The following code in {language} failed with this error:\n{error}\n"
                f"Code:\n{code}\n"
                "Analyze the error, fix the code, and return the corrected version with explanations."
            )
            debug_response = ollama.generate(model="mistral", prompt=debug_prompt)
            fixed_code = debug_response['response']
            save_code_to_file(fixed_code, filename)
            return f"خطا پیدا شد:\n{error}\nکد اصلاح‌شده:\n{fixed_code}"
    except subprocess.TimeoutExpired:
        return "اجرای کد بیش از حد طول کشید."
    except Exception as e:
        return f"خطا در تست کد: {str(e)}"

# تابع ذخیره‌سازی کد
def save_code_to_file(code, filename):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(code)
    return f"کد در '{filename}' ذخیره شد."

# تحلیل احساسات
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2: return "happy", QColor(0, 128, 0)
    elif analysis.sentiment.polarity < -0.2: return "sad", QColor(255, 0, 0)
    else: return "neutral", QColor(0, 0, 255)

# تولید پاسخ
def generate_response(user_input, sentiment, memory, emotion_system, mech_calculator):
    memory.append({"user": user_input, "sentiment": sentiment})
    with open("memory.json", "w") as f:
        json.dump(memory, f)

    input_lower = user_input.lower()
    # پاسخ‌های احساسی
    if "i love you" in input_lower:
        return random.choice(["I love you too! ❤️", "You make me so happy! 😊"])
    elif "how are you" in input_lower or "how do you feel" in input_lower:
        return emotion_system.get_emotion_response()
    elif "who deserves to die" in input_lower or "who deserves the death penalty" in input_lower:
        return "As an AI, I’m not allowed to make that choice."

    # طراحی مکانیکی
    elif "design" in input_lower and any(x in input_lower for x in ["box", "arm", "shaft", "mechanism", "cnc", "robotic arm"]):
        design_data = mech_calculator.design_mechanism(user_input)
        step_result = mech_calculator.generate_step_model(design_data)
        simulation_result = mech_calculator.simulate_motion(design_data)
        return f"Design Parameters: {design_data}\n{step_result}\nSimulation:\n{simulation_result}"

    # برنامه‌نویسی
    elif any(x in input_lower for x in ["python", "go", "c++", "c", "java", "javascript", "php", "ruby", "code"]):
        languages = ["python", "go", "c", "cpp", "java", "javascript", "php", "ruby"]
        detected_language = next((lang for lang in languages if lang in input_lower), None)
        if not detected_language:
            return "لطفاً زبان برنامه‌نویسی رو مشخص کن (مثلاً Python، Java)."
        code = generate_programming_code(user_input)
        extensions = {"python": "py", "go": "go", "c": "c", "cpp": "cpp", "java": "java", "javascript": "js", "php": "php", "ruby": "rb"}
        ext = extensions.get(detected_language, "txt")
        filename = f"generated_code.{ext}"
        save_result = save_code_to_file(code, filename)
        test_result = test_and_debug_code(code, detected_language, filename)
        return f"کد تولید‌شده:\n{code}\n\n{save_result}\n\n{test_result}"

    # پاسخ پیش‌فرض
    else:
        prompt = f"The user is feeling {sentiment} and said: {user_input}\nRespond in a {emotion_system.current_emotion} manner (keep it short and human-like):"
        response = ollama.generate(model="mistral", prompt=prompt)
        return response['response']

# تبدیل متن به گفتار
def text_to_speech(text):
    try:
        if os.path.exists("response.mp3"):
            pygame.mixer.music.stop()
            pygame.mixer.music.unload()
            time.sleep(0.1)
            os.remove("response.mp3")
        tts = gTTS(text=text, lang='en')
        tts.save("response.mp3")
        pygame.mixer.music.load("response.mp3")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy(): 
            pygame.time.Clock().tick(10)
    except Exception as e:
        print(f"gTTS failed: {e}. Switching to pyttsx3...")
        engine.say(text)
        engine.runAndWait()

# ترد برای تصویربرداری
class CaptureImageThread(QThread):
    image_captured = pyqtSignal(str)
    def run(self):
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.image_captured.emit("Error: Could not open camera.")
            return
        ret, frame = cap.read()
        if ret:
            image_path = "captured_image.png"
            cv2.imwrite(image_path, frame)
            self.image_captured.emit(image_path)
        cap.release()

# ترد برای تشخیص صوت
class SpeechRecognitionThread(QThread):
    speech_text = pyqtSignal(str)
    activation_signal = pyqtSignal()
    def run(self):
        model_path = r"C:\Users\Mohamad\Desktop\chatbot\vosk-model-small-en-us-0.15"
        if not os.path.exists(model_path):
            self.speech_text.emit("Error: Vosk model not found.")
            return
        model = vosk.Model(model_path)
        samplerate = 16000
        device = 1
        q = queue.Queue()
        def callback(indata, frames, time, status):
            if status: print(status, file=sys.stderr)
            q.put(bytes(indata))
        with sd.RawInputStream(samplerate=samplerate, blocksize=8000, device=device, dtype='int16', channels=1, callback=callback):
            rec = vosk.KaldiRecognizer(model, samplerate)
            while True:
                data = q.get()
                if rec.AcceptWaveform(data):
                    result = json.loads(rec.Result())
                    text = result['text'].lower()
                    if "zero" in text:
                        self.activation_signal.emit()
                        while True:
                            data = q.get()
                            if rec.AcceptWaveform(data):
                                result = json.loads(rec.Result())
                                command = result['text']
                                if command.strip():
                                    self.speech_text.emit(command)
                                    break

# رابط کاربری اصلی
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.avatar = Avatar()
        self.memory = self.load_memory()
        self.emotion_system = EmotionSystem()
        self.mech_calculator = MechanicalEngineeringCalculator()
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.avatar.draw)
        self.timer.start(1000)
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.activation_signal.connect(self.activate_bot)
        self.voice_thread.start()

    def load_memory(self):
        if os.path.exists("memory.json"):
            with open("memory.json", "r") as f:
                return json.load(f)
        return []

    def initUI(self):
        self.setWindowTitle("Zero - Ultimate Engineering Companion")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("""
            QWidget { background-color: #2E3440; color: #D8DEE9; }
            QTextEdit { background-color: #3B4252; color: #ECEFF4; border: 1px solid #4C566A; border-radius: 5px; padding: 10px; }
            QLineEdit { background-color: #3B4252; color: #ECEFF4; border: 1px solid #4C566A; border-radius: 5px; padding: 10px; }
            QPushButton { background-color: #5E81AC; color: #ECEFF4; border: none; border-radius: 5px; padding: 10px; }
            QPushButton:hover { background-color: #81A1C1; }
        """)
        layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)
        input_layout = QHBoxLayout()
        self.user_input = QLineEdit()
        self.user_input.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.user_input)
        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        input_layout.addWidget(send_button)
        voice_button = QPushButton("🎤")
        voice_button.clicked.connect(self.start_voice_input)
        input_layout.addWidget(voice_button)
        capture_button = QPushButton("📷")
        capture_button.clicked.connect(self.capture_image)
        input_layout.addWidget(capture_button)
        layout.addLayout(input_layout)
        self.setLayout(layout)
        self.chat_display.append(f"Zero is ready to assist! Say 'zero' to activate. (Date: {time.strftime('%Y-%m-%d')})\n")

    def send_message(self):
        user_message = self.user_input.text()
        if not user_message.strip(): return
        sentiment, color = analyze_sentiment(user_message)
        self.chat_display.append(f"You: {user_message}")
        self.chat_display.setTextColor(color)
        self.user_input.clear()
        self.emotion_system.update_emotion(sentiment)
        QTimer.singleShot(1000, lambda: self.show_response(user_message, sentiment))

    def show_response(self, user_message, sentiment):
        response = generate_response(user_message, sentiment, self.memory, self.emotion_system, self.mech_calculator)
        self.chat_display.append(f"Zero: {response}\n")
        text_to_speech(response)
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        self.avatar.update_expression(self.emotion_system.current_emotion)

    def start_voice_input(self):
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.start()

    def handle_voice_input(self, text):
        self.user_input.setText(text)
        self.send_message()

    def activate_bot(self):
        self.chat_display.append("Zero activated! How can I help you?\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

    def capture_image(self):
        self.capture_thread = CaptureImageThread()
        self.capture_thread.image_captured.connect(self.handle_captured_image)
        self.capture_thread.start()

    def handle_captured_image(self, image_path):
        self.chat_display.append(f"Image captured: {image_path}\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    chatbot = ChatbotGUI()
    chatbot.show()
    pygame_thread = pygame.threads.Thread(target=chatbot.avatar.run)
    pygame_thread.start()
    sys.exit(app.exec())