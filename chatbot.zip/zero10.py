import sys
import os
import pygame
import cv2
import queue
import sounddevice as sd
import vosk
import json
import cadquery as cq
from cadquery import exporters
import ollama
import numpy as np
import subprocess
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QHBoxLayout
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QTextCursor, QColor
from textblob import TextBlob
from gtts import gTTS
import pyttsx3
import time
import random

# مقداردهی اولیه
pygame.mixer.init()
engine = pyttsx3.init()

# کلاس آواتار
class Avatar:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Zero Avatar")
        self.running = True
        self.expression = (0, 0, 255)  # Default blue (neutral)

    def update_expression(self, emotion):
        if emotion == "happy": self.expression = (0, 128, 0)  # Green
        elif emotion == "sad": self.expression = (255, 0, 0)  # Red
        elif emotion == "angry": self.expression = (128, 0, 0)  # Dark Red
        elif emotion == "surprised": self.expression = (255, 165, 0)  # Orange
        elif emotion == "fearful": self.expression = (128, 0, 128)  # Purple
        else: self.expression = (0, 0, 255)  # Blue
        self.draw()

    def draw(self):
        if self.running and pygame.display.get_init():
            self.screen.fill((255, 255, 255))
            pygame.draw.circle(self.screen, self.expression, (150, 150), 100)
            pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
        pygame.quit()

# سیستم احساسات
class EmotionSystem:
    def __init__(self):
        self.emotions = {"happy": 0, "sad": 0, "angry": 0, "surprised": 0, "fearful": 0, "neutral": 100}
        self.current_emotion = "neutral"

    def update_emotion(self, sentiment):
        try:
            if sentiment == "happy":
                self.emotions["happy"] += 10
                self.emotions["sad"] -= 5
                self.emotions["angry"] -= 5
            elif sentiment == "sad":
                self.emotions["sad"] += 10
                self.emotions["happy"] -= 5
                self.emotions["angry"] += 5
            elif sentiment == "angry":
                self.emotions["angry"] += 10
                self.emotions["happy"] -= 5
                self.emotions["sad"] += 5
            else:
                self.emotions["neutral"] += 5
            
            for emotion in self.emotions:
                self.emotions[emotion] = max(0, min(100, self.emotions[emotion]))
            self.current_emotion = max(self.emotions, key=self.emotions.get)
        except Exception as e:
            print(f"Error in update_emotion: {str(e)}")

    def get_emotion_response(self):
        try:
            if self.current_emotion == "happy": return random.choice(["I'm happy! 😊", "Feeling great! 🌟"])
            elif self.current_emotion == "sad": return random.choice(["I'm feeling down. 😢", "Not my best day..."])
            elif self.current_emotion == "angry": return random.choice(["I'm upset! 😠", "This is frustrating."])
            elif self.current_emotion == "surprised": return random.choice(["Wow! 😮", "That's surprising!"])
            elif self.current_emotion == "fearful": return random.choice(["I'm scared! 😨", "This is worrying..."])
            else: return random.choice(["I'm okay. 🤔", "Feeling neutral."])
        except Exception as e:
            print(f"Error in get_emotion_response: {str(e)}")
            return "I'm okay."

# ماشین‌حساب مهندسی مکانیک (اصلاح‌شده)
class MechanicalEngineeringCalculator:
    def design_mechanism(self, user_input):
        try:
            prompt = (
                f"The user requested: {user_input}\n"
                "Return a detailed Python dictionary for a mechanical component with: "
                "dimensions (e.g., width, height, depth for a box; reach, joints, gripper_size for a robotic arm; diameter, length for a shaft), "
                "material (specific alloy, e.g., '6061 Aluminum', 'AISI 4140 Steel'), "
                "tolerance (in mm, e.g., 0.005), "
                "connection type (e.g., 'M6 bolts', 'TIG weld'), "
                "load capacity (in Newtons), "
                "and standard (e.g., 'ISO 4762', 'ASME B18.3'). "
                "Use realistic defaults if specifics are missing. All numeric values as numbers. "
                "For a robotic arm, ensure 'reach' and 'joints' are included. "
                "Examples: {{'reach': 2, 'joints': 4, 'gripper_size': 0.05, 'material': 'Steel', 'tolerance': 0.005}} for a robotic arm."
            )
            response = ollama.generate(model="mistral", prompt=prompt)
            design_data = eval(response['response'])

            # بررسی و اصلاح پارامترها
            if "robotic arm" in user_input.lower():
                if 'reach' not in design_data or 'joints' not in design_data:
                    design_data = {
                        'reach': 2.0,  # مقدار پیش‌فرض برای بازوی رباتیک
                        'joints': 4,
                        'gripper_size': 0.05,
                        'material': '6061 Aluminum',
                        'tolerance': 0.005,
                        'connection': 'M6 bolts',
                        'load_capacity': 1000,
                        'standard': 'ISO 4762'  # اضافه کردن استاندارد پیش‌فرض
                    }
            else:
                design_data.setdefault('material', '6061 Aluminum')
                design_data.setdefault('tolerance', 0.005)
                design_data.setdefault('connection', 'M6 bolts')
                design_data.setdefault('load_capacity', 1000)
                design_data.setdefault('standard', 'ISO 4762')  # اضافه کردن استاندارد پیش‌فرض

            # تبدیل مقادیر رشته‌ای به عددی
            for key in design_data:
                if isinstance(design_data[key], str) and design_data[key].replace(".", "").isdigit():
                    design_data[key] = float(design_data[key])

            # تحلیل تنش ساده
            if 'load_capacity' in design_data and 'diameter' in design_data:
                stress = design_data['load_capacity'] / (3.14159 * (design_data['diameter']/2)**2)
                design_data['max_stress'] = stress  # پاسکال

            return design_data
        except Exception as e:
            print(f"Error in design_mechanism: {str(e)}")
            return {'reach': 2.0, 'joints': 4, 'gripper_size': 0.05, 'material': '6061 Aluminum', 'tolerance': 0.005, 'connection': 'M6 bolts', 'standard': 'ISO 4762'}

    def generate_step_model(self, design_data, filename="mechanism.step", stl_filename="mechanism.stl", dxf_filename="mechanism.dxf", render_filename="mechanism_render.png"):
        try:
            result = cq.Workplane("XY")
            bom = []

            # اولویت دادن به بازوی رباتیک
            if "reach" in design_data:  # ربات بازویی
                reach = design_data.get("reach", 1)
                joints = design_data.get("joints", 3)
                segment_length = reach / joints
                gripper_size = design_data.get("gripper_size", 0.05)

                # پایه با پیچ‌های استاندارد
                base = cq.Workplane("XY").box(segment_length * 0.5, segment_length * 0.5, 0.05).fillet(0.005)
                base = base.faces(">Z").workplane().pushPoints([(-0.1, -0.1), (-0.1, 0.1), (0.1, -0.1), (0.1, 0.1)]).hole(0.006)  # M6
                bom.append({"part": "Base", "width": segment_length * 0.5, "material": design_data['material'], "standard": design_data.get('standard', 'ISO 4762')})

                # بازوها با بلبرینگ و موتور
                arm = base
                for i in range(joints):
                    segment = cq.Workplane("XY").box(segment_length, 0.03, 0.03).translate((segment_length * i + segment_length/2, 0, 0.05))
                    joint = cq.Workplane("XY").circle(0.015).extrude(0.04).translate((segment_length * (i + 1), 0, 0.05))
                    bearing = cq.Workplane("XY").circle(0.012).extrude(0.01).translate((segment_length * (i + 1), 0, 0.05))
                    motor = cq.Workplane("XY").box(0.04, 0.04, 0.03).translate((segment_length * (i + 1), 0.06, 0.05))
                    arm = arm.union(segment).union(joint).union(bearing).union(motor)
                    bom.append({"part": f"Segment {i+1}", "length": segment_length, "material": design_data['material']})
                    bom.append({"part": f"Bearing {i+1}", "diameter": 0.024, "material": "Steel"})
                    bom.append({"part": f"Servo Motor {i+1}", "width": 0.04, "material": "Plastic"})

                # گریپر با مکانیزم دقیق
                gripper_base = cq.Workplane("XY").box(gripper_size, gripper_size * 0.3, gripper_size * 0.3).translate((reach + gripper_size/2, 0, 0.05))
                finger1 = cq.Workplane("XY").box(gripper_size * 0.2, gripper_size * 0.1, gripper_size * 0.4).translate((reach + gripper_size/2, gripper_size * 0.15, 0.05))
                finger2 = cq.Workplane("XY").box(gripper_size * 0.2, gripper_size * 0.1, gripper_size * 0.4).translate((reach + gripper_size/2, -gripper_size * 0.15, 0.05))
                arm = arm.union(gripper_base).union(finger1).union(finger2)
                bom.append({"part": "Gripper", "width": gripper_size, "material": design_data['material']})

                result = arm

            elif "width" in design_data:  # جعبه
                width = design_data.get("width", 0.1)
                height = design_data.get("height", 0.1)
                depth = design_data.get("depth", 0.1)
                result = result.box(width, height, depth).fillet(0.005)
                bom.append({"part": "Body", "width": width, "height": height, "depth": depth, 
                            "material": design_data['material'], "tolerance": design_data['tolerance']})

            elif "diameter" in design_data:  # شفت
                diameter = design_data.get("diameter", 0.05)
                length = design_data.get("length", 1)
                result = result.circle(diameter / 2).extrude(length)
                bom.append({"part": "Shaft", "diameter": diameter, "length": length, "material": design_data['material']})

            else:  # پیش‌فرض
                result = result.box(0.1, 0.1, 0.1)
                bom.append({"part": "Default Box", "width": 0.1, "height": 0.1, "depth": 0.1, "material": design_data['material']})

            # تولید فایل‌ها
            exporters.export(result, filename, cq.exporters.ExportTypes.STEP)
            exporters.export(result, stl_filename, cq.exporters.ExportTypes.STL)
            exporters.export(result.section(), dxf_filename, cq.exporters.ExportTypes.DXF)

            # رندر (بعد از تولید فایل‌ها)
            render_result = self.render_with_blender(stl_filename, render_filename, bom)

            bom_report = "Bill of Materials:\n" + "\n".join([str(item) for item in bom])
            return f"STEP: {filename}\nSTL: {stl_filename}\nDXF: {dxf_filename}\nRender: {render_filename}\n{render_result}\n{bom_report}"
        except Exception as e:
            print(f"Generate error: {str(e)}")
            return f"Error: {str(e)}"

    def render_with_blender(self, stl_filename, render_filename, bom):
        try:
            blender_path = "blender"  # فرض می‌کنیم Blender توی PATH هست
            if not os.path.exists(stl_filename):
                return f"Error: STL file '{stl_filename}' not found."

            blender_script = """
import bpy
import os
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
bpy.ops.import_mesh.stl(filepath="{}")
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        mat = bpy.data.materials.new(name=obj.name + "_material")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = next(node for node in nodes if node.type == 'BSDF_PRINCIPLED')
        color = (0.7, 0.7, 0.7, 1)  # Default silver
        for item in {}
            if item['part'] in obj.name:
                color = (0.7, 0.7, 0.7, 1) if 'Aluminum' in item['material'] else (0.5, 0.5, 0.5, 1)
                break
        principled.inputs['Base Color'].default_value = color
        obj.data.materials.append(mat)
bpy.ops.object.light_add(type='SUN', location=(5, 5, 5))
bpy.context.scene.render.engine = 'CYCLES'
bpy.context.scene.render.filepath = "{}"
bpy.ops.render.render(write_still=True)
bpy.ops.wm.quit_blender()
""".format(os.path.abspath(stl_filename), bom, os.path.abspath(render_filename))

            with open("render_script.py", "w", encoding="utf-8") as f:
                f.write(blender_script)
            result = subprocess.run([blender_path, "-b", "-P", "render_script.py"], capture_output=True, text=True)
            if result.returncode != 0:
                return f"Error rendering with Blender: {result.stderr}\nEnsure Blender is installed and added to PATH."
            return f"Render saved at '{render_filename}'."
        except FileNotFoundError:
            return "Error: Blender not found. Please install Blender and add it to your system PATH."
        except Exception as e:
            print(f"Render error: {str(e)}")
            return f"Error: {str(e)}"

    def simulate_motion(self, design_data):
        try:
            if "reach" in design_data:
                joints = design_data.get("joints", 3)
                reach = design_data.get("reach", 1)
                segment_length = reach / joints
                report = "Robotic arm simulation:\n"
                for i in range(joints):
                    report += f"Joint {i+1}: 45° rotation, {segment_length}m displacement\n"
                return report
            return "Simulation not supported."
        except Exception as e:
            print(f"Simulate error: {str(e)}")
            return f"Error: {str(e)}"

# مهندسی برق
class ElectricalEngineering:
    def design_circuit(self, user_input):
        try:
            if "resistor" in user_input.lower():
                voltage = float(input("Enter voltage (V): ") or 5)
                current = float(input("Enter current (A): ") or 0.01)
                resistance = voltage / current
                return f"Resistance: {resistance} Ohms (V={voltage}, I={current})"
            return "Specify circuit type (e.g., 'resistor calculation')."
        except Exception as e:
            return f"Error: {str(e)}"

# تولید کد برنامه‌نویسی
def generate_programming_code(user_input):
    try:
        prompt = (
            f"The user requested: {user_input}\n"
            "Generate optimized, production-ready code in the specified language. "
            "Support frameworks (e.g., Django, React) if relevant. Include unit tests and handle all edge cases."
        )
        response = ollama.generate(model="mistral", prompt=prompt)
        code = response['response']
        
        if "python" in user_input.lower():
            test_code = f"""
import pytest\n\n{code}\n\n# Unit Tests\ndef test_sample():\n    assert True  # Replace with actual test
"""
            return f"Code:\n{code}\n\nTests:\n{test_code}"
        return code
    except Exception as e:
        print(f"Error in generate_programming_code: {str(e)}")
        return "Error generating code."

def test_and_debug_code(code, language, filename):
    try:
        save_code_to_file(code, filename)
        compilers = {
            "python": ["python", filename],
            "go": ["go", "run", filename],
            "c": ["gcc", filename, "-o", "test_output"],
            "cpp": ["g++", filename, "-o", "test_output"],
            "java": ["javac", filename],
            "javascript": ["node", filename],
            "php": ["php", filename],
            "ruby": ["ruby", filename],
        }
        if language not in compilers:
            return f"Testing not supported for {language}."
        result = subprocess.run(compilers[language], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            if language in ["c", "cpp"]:
                exec_result = subprocess.run("./test_output" if os.name != "nt" else "test_output.exe", 
                                            capture_output=True, text=True, timeout=10)
                return f"Code executed successfully:\n{exec_result.stdout}"
            return f"Code executed successfully:\n{result.stdout}"
        else:
            error = result.stderr
            debug_prompt = (
                f"The following code in {language} failed with this error:\n{error}\n"
                f"Code:\n{code}\n"
                "Analyze the error, fix the code, and return the corrected version with explanations."
            )
            debug_response = ollama.generate(model="mistral", prompt=debug_prompt)
            fixed_code = debug_response['response']
            save_code_to_file(fixed_code, filename)
            return f"Error found:\n{error}\nFixed code:\n{fixed_code}"
    except subprocess.TimeoutExpired:
        return "Code execution timed out."
    except Exception as e:
        print(f"Error in test_and_debug_code: {str(e)}")
        return f"Error in testing code: {str(e)}"

def save_code_to_file(code, filename):
    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write(code)
        return f"Code saved at '{filename}'."
    except Exception as e:
        print(f"Error in save_code_to_file: {str(e)}")
        return f"Error saving code: {str(e)}"

# تحلیل احساسات
def analyze_sentiment(text):
    try:
        analysis = TextBlob(text)
        if analysis.sentiment.polarity > 0.2: return "happy", QColor(0, 128, 0)
        elif analysis.sentiment.polarity < -0.2: return "sad", QColor(255, 0, 0)
        else: return "neutral", QColor(0, 0, 255)
    except Exception as e:
        print(f"Error in analyze_sentiment: {str(e)}")
        return "neutral", QColor(0, 0, 255)

# تولید پاسخ
def generate_response(user_input, sentiment, memory, emotion_system, mech_calculator, elec_calculator):
    try:
        memory.append({"user": user_input, "sentiment": sentiment})
        with open("memory.json", "w", encoding="utf-8") as f:
            json.dump(memory, f)

        input_lower = user_input.lower()
        if "i love you" in input_lower:
            return random.choice(["I love you too! ❤️", "You make me so happy! 😊"])
        elif "how are you" in input_lower or "how do you feel" in input_lower:
            return emotion_system.get_emotion_response()
        elif "who deserves to die" in input_lower or "who deserves the death penalty" in input_lower:
            return "As an AI, I’m not allowed to make that choice."
        elif "design" in input_lower and any(x in input_lower for x in ["box", "arm", "shaft", "mechanism", "cnc", "robotic arm"]):
            design_data = mech_calculator.design_mechanism(user_input)
            step_result = mech_calculator.generate_step_model(design_data)
            simulation_result = mech_calculator.simulate_motion(design_data)
            return f"Design Parameters: {design_data}\n{step_result}\nSimulation:\n{simulation_result}"
        elif "circuit" in input_lower or "resistor" in input_lower:
            return elec_calculator.design_circuit(user_input)
        elif any(x in input_lower for x in ["python", "go", "c++", "c", "java", "javascript", "php", "ruby", "code"]):
            languages = ["python", "go", "c", "cpp", "java", "javascript", "php", "ruby"]
            detected_language = next((lang for lang in languages if lang in input_lower), None)
            if not detected_language:
                return "Please specify the programming language (e.g., Python, Java)."
            code = generate_programming_code(user_input)
            extensions = {"python": "py", "go": "go", "c": "c", "cpp": "cpp", "java": "java", "javascript": "js", "php": "php", "ruby": "rb"}
            ext = extensions.get(detected_language, "txt")
            filename = f"generated_code.{ext}"
            save_result = save_code_to_file(code, filename)
            test_result = test_and_debug_code(code, detected_language, filename)
            return f"Generated code:\n{code}\n\n{save_result}\n\n{test_result}"
        else:
            prompt = f"The user is feeling {sentiment} and said: {user_input}\nRespond in a {emotion_system.current_emotion} manner (keep it short and human-like):"
            response = ollama.generate(model="mistral", prompt=prompt)
            return response['response']
    except Exception as e:
        print(f"Error in generate_response: {str(e)}")
        return "Sorry, I encountered an error."

# تبدیل متن به گفتار
def text_to_speech(text):
    try:
        if not any(keyword in text.lower() for keyword in ["step", "stl", "code", "resistance", "simulation", "dxf", "render"]):
            if os.path.exists("response.mp3"):
                pygame.mixer.music.stop()
                pygame.mixer.music.unload()
                time.sleep(0.1)
                os.remove("response.mp3")
            tts = gTTS(text=text, lang='en')
            tts.save("response.mp3")
            pygame.mixer.music.load("response.mp3")
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                pygame.time.Clock().tick(10)
    except Exception as e:
        print(f"gTTS failed: {e}. Switching to pyttsx3...")
        try:
            if not any(keyword in text.lower() for keyword in ["step", "stl", "code", "resistance", "simulation", "dxf", "render"]):
                engine.say(text)
                engine.runAndWait()
        except Exception as e2:
            print(f"pyttsx3 failed: {str(e2)}")

# ترد برای تصویربرداری
class CaptureImageThread(QThread):
    image_captured = pyqtSignal(str)
    def run(self):
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                self.image_captured.emit("Error: Could not open camera.")
                return
            ret, frame = cap.read()
            if ret:
                image_path = "captured_image.png"
                cv2.imwrite(image_path, frame)
                self.image_captured.emit(image_path)
            cap.release()
        except Exception as e:
            print(f"Error in CaptureImageThread: {str(e)}")
            self.image_captured.emit(f"Error capturing image: {str(e)}")

# ترد برای تشخیص صوت
class SpeechRecognitionThread(QThread):
    speech_text = pyqtSignal(str)
    activation_signal = pyqtSignal()
    def run(self):
        try:
            model_path = r"C:\Users\Mohamad\Desktop\chatbot\vosk-model-small-en-us-0.15"
            if not os.path.exists(model_path):
                self.speech_text.emit("Error: Vosk model not found.")
                return
            model = vosk.Model(model_path)
            samplerate = 16000
            device = 1
            q = queue.Queue()
            def callback(indata, frames, time, status):
                if status: print(status, file=sys.stderr)
                q.put(bytes(indata))
            with sd.RawInputStream(samplerate=samplerate, blocksize=8000, device=device, dtype='int16', channels=1, callback=callback):
                rec = vosk.KaldiRecognizer(model, samplerate)
                while True:
                    data = q.get()
                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result())
                        text = result['text'].lower()
                        if "zero" in text:
                            self.activation_signal.emit()
                            while True:
                                data = q.get()
                                if rec.AcceptWaveform(data):
                                    result = json.loads(rec.Result())
                                    command = result['text']
                                    if command.strip():
                                        self.speech_text.emit(command)
                                        break
        except Exception as e:
            print(f"Error in SpeechRecognitionThread: {str(e)}")
            self.speech_text.emit(f"Error in speech recognition: {str(e)}")

# رابط کاربری اصلی
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.avatar = Avatar()
        self.memory = self.load_memory()
        self.emotion_system = EmotionSystem()
        self.mech_calculator = MechanicalEngineeringCalculator()
        self.elec_calculator = ElectricalEngineering()
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.avatar.draw)
        self.timer.start(1000)
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.activation_signal.connect(self.activate_bot)
        self.voice_thread.start()

    def load_memory(self):
        try:
            if os.path.exists("memory.json"):
                with open("memory.json", "r", encoding="utf-8") as f:
                    return json.load(f)
            return []
        except Exception as e:
            print(f"Error in load_memory: {str(e)}")
            return []

    def initUI(self):
        try:
            self.setWindowTitle("Zero - Ultimate Engineering Companion")
            self.setGeometry(100, 100, 800, 600)
            self.setStyleSheet("""
                QWidget { background-color: #2E3440; color: #D8DEE9; }
                QTextEdit { background-color: #3B4252; color: #ECEFF4; border: 1px solid #4C566A; border-radius: 5px; padding: 10px; }
                QLineEdit { background-color: #3B4252; color: #ECEFF4; border: 1px solid #4C566A; border-radius: 5px; padding: 10px; }
                QPushButton { background-color: #5E81AC; color: #ECEFF4; border: none; border-radius: 5px; padding: 10px; }
                QPushButton:hover { background-color: #81A1C1; }
            """)
            layout = QVBoxLayout()
            self.chat_display = QTextEdit()
            self.chat_display.setReadOnly(True)
            layout.addWidget(self.chat_display)
            input_layout = QHBoxLayout()
            self.user_input = QLineEdit()
            self.user_input.returnPressed.connect(self.send_message)
            input_layout.addWidget(self.user_input)
            send_button = QPushButton("Send")
            send_button.clicked.connect(self.send_message)
            input_layout.addWidget(send_button)
            voice_button = QPushButton("🎤")
            voice_button.clicked.connect(self.start_voice_input)
            input_layout.addWidget(voice_button)
            capture_button = QPushButton("📷")
            capture_button.clicked.connect(self.capture_image)
            input_layout.addWidget(capture_button)
            layout.addLayout(input_layout)
            self.setLayout(layout)
            self.chat_display.append(f"Zero is ready to assist! Say 'zero' to activate. (Date: {time.strftime('%Y-%m-%d')})\n")
        except Exception as e:
            print(f"Error in initUI: {str(e)}")

    def send_message(self):
        try:
            user_message = self.user_input.text()
            if not user_message.strip(): return
            sentiment, color = analyze_sentiment(user_message)
            self.chat_display.append(f"You: {user_message}")
            self.chat_display.setTextColor(color)
            self.user_input.clear()
            self.emotion_system.update_emotion(sentiment)
            QTimer.singleShot(1000, lambda: self.show_response(user_message, sentiment))
        except Exception as e:
            print(f"Error in send_message: {str(e)}")

    def show_response(self, user_message, sentiment):
        try:
            response = generate_response(user_message, sentiment, self.memory, self.emotion_system, self.mech_calculator, self.elec_calculator)
            self.chat_display.append(f"Zero: {response}\n")
            text_to_speech(response)
            self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
            self.avatar.update_expression(self.emotion_system.current_emotion)
        except Exception as e:
            print(f"Error in show_response: {str(e)}")
            self.chat_display.append(f"Zero: Error processing response: {str(e)}\n")

    def start_voice_input(self):
        try:
            self.voice_thread = SpeechRecognitionThread()
            self.voice_thread.speech_text.connect(self.handle_voice_input)
            self.voice_thread.start()
        except Exception as e:
            print(f"Error in start_voice_input: {str(e)}")

    def handle_voice_input(self, text):
        try:
            self.user_input.setText(text)
            self.send_message()
        except Exception as e:
            print(f"Error in handle_voice_input: {str(e)}")

    def activate_bot(self):
        try:
            self.chat_display.append("Zero activated! How can I help you?\n")
            self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        except Exception as e:
            print(f"Error in activate_bot: {str(e)}")

    def capture_image(self):
        try:
            self.capture_thread = CaptureImageThread()
            self.capture_thread.image_captured.connect(self.handle_captured_image)
            self.capture_thread.start()
        except Exception as e:
            print(f"Error in capture_image: {str(e)}")

    def handle_captured_image(self, image_path):
        try:
            self.chat_display.append(f"Image captured: {image_path}\n")
            self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        except Exception as e:
            print(f"Error in handle_captured_image: {str(e)}")

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        chatbot = ChatbotGUI()
        chatbot.show()
        pygame_thread = pygame.threads.Thread(target=chatbot.avatar.run)
        pygame_thread.start()
        sys.exit(app.exec())
    except Exception as e:
        print(f"Error in main: {str(e)}")