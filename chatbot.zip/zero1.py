import sys
import os
import requests
import pygame
from bs4 import BeautifulSoup
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QTextCursor, QColor
from textblob import TextBlob
import ollama
from gtts import gTTS

# Avatar class for Pygame visualization
class Avatar:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Zero Avatar")
        self.running = True
        self.expression = (0, 0, 255)  # Default blue (neutral)

    def update_expression(self, sentiment):
        if sentiment == "happy":
            self.expression = (0, 128, 0)  # Green
        elif sentiment == "sad":
            self.expression = (255, 0, 0)  # Red
        else:
            self.expression = (0, 0, 255)  # Blue
        self.draw()

    def draw(self):
        self.screen.fill((255, 255, 255))
        pygame.draw.circle(self.screen, self.expression, (150, 150), 100)
        pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
        pygame.quit()

# Sentiment analysis function
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:
        return "happy", QColor(0, 128, 0)
    elif analysis.sentiment.polarity < -0.2:
        return "sad", QColor(255, 0, 0)
    else:
        return "neutral", QColor(0, 0, 255)

# Generate response using Mistral
def generate_response(user_input, sentiment):
    prompt = f"The user is feeling {sentiment} and said: {user_input}\nRespond in a friendly manner:"
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# Text to speech function
def text_to_speech(text):
    tts = gTTS(text=text, lang='en')
    tts.save("response.mp3")
    os.system("start response.mp3")

# Main chatbot GUI
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.avatar = Avatar()
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.avatar.draw)
        self.timer.start(1000)

    def initUI(self):
        self.setWindowTitle("Zero - Your Wise Companion")
        self.setGeometry(100, 100, 600, 400)
        layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)
        self.user_input = QLineEdit()
        self.user_input.returnPressed.connect(self.send_message)
        layout.addWidget(self.user_input)
        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        layout.addWidget(send_button)
        self.setLayout(layout)

    def send_message(self):
        user_message = self.user_input.text()
        if not user_message.strip():
            return
        sentiment, color = analyze_sentiment(user_message)
        response = generate_response(user_message, sentiment)
        self.chat_display.append(f"You: {user_message}")
        self.chat_display.setTextColor(color)
        self.chat_display.append(f"Zero: {response}\n")
        text_to_speech(response)
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        self.avatar.update_expression(sentiment)
        self.user_input.clear()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    chatbot = ChatbotGUI()
    chatbot.show()
    pygame_thread = pygame.threads.Thread(target=chatbot.avatar.run)
    pygame_thread.start()
    sys.exit(app.exec())
