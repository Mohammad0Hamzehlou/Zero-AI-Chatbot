import sys
import os
import pygame
import cv2
import queue
import sounddevice as sd
import vosk
import json
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QLabel, QHBoxLayout
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QTextCursor, QColor, QFont, QPixmap, QIcon
from textblob import TextBlob
import ollama
from gtts import gTTS
import pyttsx3  # جایگزین آفلاین برای gTTS
import time
import random

# Initialize pygame mixer
pygame.mixer.init()

# Initialize pyttsx3 engine globally
engine = pyttsx3.init()

# Avatar class for Pygame visualization
class Avatar:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Zero Avatar")
        self.running = True
        self.expression = (0, 0, 255)  # Default blue (neutral)

    def update_expression(self, emotion):
        if emotion == "happy":
            self.expression = (0, 128, 0)  # Green
        elif emotion == "sad":
            self.expression = (255, 0, 0)  # Red
        elif emotion == "angry":
            self.expression = (128, 0, 0)  # Dark Red
        elif emotion == "surprised":
            self.expression = (255, 165, 0)  # Orange
        elif emotion == "fearful":
            self.expression = (128, 0, 128)  # Purple
        else:
            self.expression = (0, 0, 255)  # Blue
        self.draw()

    def draw(self):
        self.screen.fill((255, 255, 255))
        pygame.draw.circle(self.screen, self.expression, (150, 150), 100)
        pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
        pygame.quit()

# Sentiment analysis function
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:
        return "happy", QColor(0, 128, 0)
    elif analysis.sentiment.polarity < -0.2:
        return "sad", QColor(255, 0, 0)
    else:
        return "neutral", QColor(0, 0, 255)

# Emotion system
class EmotionSystem:
    def __init__(self):
        self.emotions = {
            "happy": 0,
            "sad": 0,
            "angry": 0,
            "surprised": 0,
            "fearful": 0,
            "neutral": 100
        }
        self.current_emotion = "neutral"

    def update_emotion(self, sentiment):
        if sentiment == "happy":
            self.emotions["happy"] += 10
            self.emotions["sad"] -= 5
            self.emotions["angry"] -= 5
        elif sentiment == "sad":
            self.emotions["sad"] += 10
            self.emotions["happy"] -= 5
            self.emotions["angry"] += 5
        elif sentiment == "angry":
            self.emotions["angry"] += 10
            self.emotions["happy"] -= 5
            self.emotions["sad"] += 5
        else:
            self.emotions["neutral"] += 5

        # Normalize emotions
        total = sum(self.emotions.values())
        for emotion in self.emotions:
            self.emotions[emotion] = max(0, min(100, self.emotions[emotion]))

        # Update current emotion
        self.current_emotion = max(self.emotions, key=self.emotions.get)

    def get_emotion_response(self):
        if self.current_emotion == "happy":
            return random.choice([
                "I'm happy! 😊",
                "Feeling great! 🌟",
                "So glad to hear that!"
            ])
        elif self.current_emotion == "sad":
            return random.choice([
                "I'm feeling down. 😢",
                "Not my best day...",
                "This makes me sad."
            ])
        elif self.current_emotion == "angry":
            return random.choice([
                "I'm upset! 😠",
                "This is frustrating.",
                "I don't like this."
            ])
        elif self.current_emotion == "surprised":
            return random.choice([
                "Wow! 😮",
                "That's surprising!",
                "I didn't expect that!"
            ])
        elif self.current_emotion == "fearful":
            return random.choice([
                "I'm scared! 😨",
                "This is worrying...",
                "I feel uneasy."
            ])
        else:
            return random.choice([
                "I'm okay. 🤔",
                "Feeling neutral.",
                "Nothing special."
            ])

# تابع برای پاسخ به سوالات برنامه‌نویسی
def generate_programming_response(user_input):
    # استفاده از مدل زبانی برای پاسخ به سوالات برنامه‌نویسی
    prompt = f"The user asked a programming question: {user_input}\nProvide a detailed and accurate answer:"
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# تابع برای ذخیره‌سازی کد در یک فایل
def save_code_to_file(code, filename="generated_code.py"):
    try:
        with open(filename, "w") as file:
            file.write(code)
        return f"Code saved successfully to {filename}"
    except Exception as e:
        return f"Error saving code: {str(e)}"

# Generate response using Mistral
def generate_response(user_input, sentiment, memory, emotion_system):
    # یادگیری از مکالمات گذشته
    memory.append({"user": user_input, "sentiment": sentiment})
    with open("memory.json", "w") as f:
        json.dump(memory, f)

    # پاسخ‌های خاص برای عبارات خاص
    if "i love you" in user_input.lower():
        return random.choice([
            "I love you too! ❤️",
            "You make me so happy! 😊",
            "That means a lot to me!"
        ])
    elif "how are you" in user_input.lower() or "how do you feel" in user_input.lower():
        return emotion_system.get_emotion_response()
    elif "python" in user_input.lower() or "code" in user_input.lower() or "programming" in user_input.lower():
        response = generate_programming_response(user_input)
        # اگر کاربر درخواست ذخیره‌سازی کد را داد
        if "save code" in user_input.lower() or "ذخیره کد" in user_input.lower():
            # استخراج نام فایل از ورودی کاربر (اگر وجود داشته باشد)
            filename = "generated_code.py"  # نام پیش‌فرض
            if "as" in user_input.lower():
                parts = user_input.lower().split("as")
                if len(parts) > 1:
                    filename = parts[1].strip() + ".py"
            save_result = save_code_to_file(response, filename)
            return f"{response}\n\n{save_result}"
        return response

    # تولید پاسخ بر اساس احساسات
    prompt = f"The user is feeling {sentiment} and said: {user_input}\nRespond in a {emotion_system.current_emotion} manner (keep it short and human-like):"
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# تابع ترکیبی برای تبدیل متن به گفتار با ریداندسی بین gTTS و pyttsx3
def text_to_speech(text):
    try:
        # حذف فایل قبلی اگر وجود دارد
        if os.path.exists("response.mp3"):
            os.remove("response.mp3")
        
        # استفاده از gTTS
        tts = gTTS(text=text, lang='en')
        tts.save("response.mp3")
        
        # Initialize pygame mixer
        pygame.mixer.init()
        
        # Stop any currently playing audio
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
        
        # Load the new audio file
        pygame.mixer.music.load("response.mp3")
        
        # Add a small delay to ensure the file is ready
        time.sleep(0.5)
        
        # Play the audio
        pygame.mixer.music.play()
        
        # Wait until the audio finishes playing
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except Exception as e:
        print(f"gTTS failed: {e}. Switching to pyttsx3...")
        # استفاده از pyttsx3 در صورت خطا
        engine.say(text)
        engine.runAndWait()

# Thread for capturing image
class CaptureImageThread(QThread):
    image_captured = pyqtSignal(str)

    def run(self):
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.image_captured.emit("Error: Could not open camera.")
            return

        # تنظیمات دوربین برای کیفیت بالا
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)  # عرض تصویر به 1920 پیکسل
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)  # ارتفاع تصویر به 1080 پیکسل
        cap.set(cv2.CAP_PROP_FPS, 30)  # نرخ فریم به 30 فریم بر ثانیه

        ret, frame = cap.read()
        if ret:
            image_path = "captured_image.png"
            # ذخیره تصویر با کیفیت بالا و بدون فشرده‌سازی
            cv2.imwrite(image_path, frame, [cv2.IMWRITE_PNG_COMPRESSION, 0])
            self.image_captured.emit(image_path)
        cap.release()

# Thread for speech recognition (Offline using Vosk)
class SpeechRecognitionThread(QThread):
    speech_text = pyqtSignal(str)
    activation_signal = pyqtSignal()  # سیگنال برای فعال‌سازی ربات

    def run(self):
        model_path = r"C:\Users\Mohamad\Desktop\chatbot\vosk-model-small-en-us-0.15"
        if not os.path.exists(model_path):
            self.speech_text.emit("Error: Vosk model not found.")
            return

        model = vosk.Model(model_path)
        samplerate = 16000
        device = 1

        q = queue.Queue()

        def callback(indata, frames, time, status):
            if status:
                print(status, file=sys.stderr)
            q.put(bytes(indata))

        try:
            with sd.RawInputStream(samplerate=samplerate, blocksize=8000, device=device,
                                  dtype='int16', channels=1, callback=callback):
                rec = vosk.KaldiRecognizer(model, samplerate)
                print("Listening for activation word...")
                while True:
                    data = q.get()
                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result())
                        text = result['text'].lower()  # تبدیل متن به حروف کوچک
                        if "zero" in text:  # فقط اگر کلمه "zero" تشخیص داده شد
                            self.activation_signal.emit()  # فعال‌سازی ربات
                            print("Activation word detected! Listening for your command...")
                            # حالا منتظر دستور بعدی کاربر می‌ماند
                            while True:
                                data = q.get()
                                if rec.AcceptWaveform(data):
                                    result = json.loads(rec.Result())
                                    command = result['text']
                                    if command.strip():  # اگر دستور خالی نبود
                                        self.speech_text.emit(command)
                                        break  # پس از دریافت دستور، به حالت انتظار برمی‌گردد
        except Exception as e:
            self.speech_text.emit(f"Error: {str(e)}")

# Main chatbot GUI
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.avatar = Avatar()
        self.memory = self.load_memory()  # بارگذاری حافظه
        self.emotion_system = EmotionSystem()  # سیستم احساسات
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.avatar.draw)
        self.timer.start(1000)

        # فعال‌سازی میکروفون به‌صورت همیشه‌روشن
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.activation_signal.connect(self.activate_bot)
        self.voice_thread.start()

    def load_memory(self):
        if os.path.exists("memory.json"):
            with open("memory.json", "r") as f:
                return json.load(f)
        return []

    def initUI(self):
        self.setWindowTitle("Zero - Your Wise Companion")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("""
            QWidget {
                background-color: #2E3440;
                color: #D8DEE9;
            }
            QTextEdit {
                background-color: #3B4252;
                color: #ECEFF4;
                border: 1px solid #4C566A;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QLineEdit {
                background-color: #3B4252;
                color: #ECEFF4;
                border: 1px solid #4C566A;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton {
                background-color: #5E81AC;
                color: #ECEFF4;
                border: none;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #81A1C1;
            }
        """)

        layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)

        input_layout = QHBoxLayout()
        self.user_input = QLineEdit()
        self.user_input.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.user_input)

        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        input_layout.addWidget(send_button)

        voice_button = QPushButton("🎤")
        voice_button.clicked.connect(self.start_voice_input)
        input_layout.addWidget(voice_button)

        capture_button = QPushButton("📷")
        capture_button.clicked.connect(self.capture_image)
        input_layout.addWidget(capture_button)

        layout.addLayout(input_layout)
        self.setLayout(layout)

        # نمایش پیام اولیه
        self.chat_display.append("Zero is waiting for the activation word 'zero'...\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

    def send_message(self):
        user_message = self.user_input.text()
        if not user_message.strip():
            return
        sentiment, color = analyze_sentiment(user_message)
        self.chat_display.append(f"You: {user_message}")
        self.chat_display.setTextColor(color)
        self.user_input.clear()

        # به‌روزرسانی احساسات بر اساس sentiment
        self.emotion_system.update_emotion(sentiment)

        # Simulate typing delay
        QTimer.singleShot(1000, lambda: self.show_response(user_message, sentiment))

    def show_response(self, user_message, sentiment):
        response = generate_response(user_message, sentiment, self.memory, self.emotion_system)
        self.chat_display.append(f"Zero: {response}\n")
        text_to_speech(response)
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        self.avatar.update_expression(self.emotion_system.current_emotion)

    def start_voice_input(self):
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.start()

    def handle_voice_input(self, text):
        self.user_input.setText(text)
        self.send_message()

    def activate_bot(self):
        # فعال‌سازی ربات پس از تشخیص کلمه "zero"
        self.chat_display.append("Zero activated! How can I help you?\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

    def capture_image(self):
        self.capture_thread = CaptureImageThread()
        self.capture_thread.image_captured.connect(self.handle_captured_image)
        self.capture_thread.start()

    def handle_captured_image(self, image_path):
        self.chat_display.append(f"Image captured: {image_path}\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    chatbot = ChatbotGUI()
    chatbot.show()
    pygame_thread = pygame.threads.Thread(target=chatbot.avatar.run)
    pygame_thread.start()
    sys.exit(app.exec())