import sys
import os
import pygame
import cv2
import queue
import sounddevice as sd
import vosk
import json
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QLabel, QHBoxLayout
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QTextCursor, QColor, QFont, QPixmap, QIcon
from textblob import TextBlob
import ollama
from gtts import gTTS
import pyttsx3
import time
import random
import numpy as np
from scipy.integrate import solve_ivp
from scipy.fft import fft
from sympy import symbols, Function, laplace_transform
import schemdraw
import schemdraw.elements as elm
import subprocess

# Initialize pygame mixer
pygame.mixer.init()

# Initialize pyttsx3 engine globally
engine = pyttsx3.init()

# Avatar class for Pygame visualization
class Avatar:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((300, 300))
        pygame.display.set_caption("Zero Avatar")
        self.running = True
        self.expression = (0, 0, 255)  # Default blue (neutral)

    def update_expression(self, emotion):
        if emotion == "happy":
            self.expression = (0, 128, 0)  # Green
        elif emotion == "sad":
            self.expression = (255, 0, 0)  # Red
        elif emotion == "angry":
            self.expression = (128, 0, 0)  # Dark Red
        elif emotion == "surprised":
            self.expression = (255, 165, 0)  # Orange
        elif emotion == "fearful":
            self.expression = (128, 0, 128)  # Purple
        else:
            self.expression = (0, 0, 255)  # Blue
        self.draw()

    def draw(self):
        self.screen.fill((255, 255, 255))
        pygame.draw.circle(self.screen, self.expression, (150, 150), 100)
        pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
        pygame.quit()

# Sentiment analysis function
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:
        return "happy", QColor(0, 128, 0)
    elif analysis.sentiment.polarity < -0.2:
        return "sad", QColor(255, 0, 0)
    else:
        return "neutral", QColor(0, 0, 255)

# Emotion system
class EmotionSystem:
    def __init__(self):
        self.emotions = {
            "happy": 0,
            "sad": 0,
            "angry": 0,
            "surprised": 0,
            "fearful": 0,
            "neutral": 100
        }
        self.current_emotion = "neutral"

    def update_emotion(self, sentiment):
        if sentiment == "happy":
            self.emotions["happy"] += 10
            self.emotions["sad"] -= 5
            self.emotions["angry"] -= 5
        elif sentiment == "sad":
            self.emotions["sad"] += 10
            self.emotions["happy"] -= 5
            self.emotions["angry"] += 5
        elif sentiment == "angry":
            self.emotions["angry"] += 10
            self.emotions["happy"] -= 5
            self.emotions["sad"] += 5
        else:
            self.emotions["neutral"] += 5

        total = sum(self.emotions.values())
        for emotion in self.emotions:
            self.emotions[emotion] = max(0, min(100, self.emotions[emotion]))

        self.current_emotion = max(self.emotions, key=self.emotions.get)

    def get_emotion_response(self):
        if self.current_emotion == "happy":
            return random.choice(["I'm happy! 😊", "Feeling great! 🌟", "So glad to hear that!"])
        elif self.current_emotion == "sad":
            return random.choice(["I'm feeling down. 😢", "Not my best day...", "This makes me sad."])
        elif self.current_emotion == "angry":
            return random.choice(["I'm upset! 😠", "This is frustrating.", "I don't like this."])
        elif self.current_emotion == "surprised":
            return random.choice(["Wow! 😮", "That's surprising!", "I didn't expect that!"])
        elif self.current_emotion == "fearful":
            return random.choice(["I'm scared! 😨", "This is worrying...", "I feel uneasy."])
        else:
            return random.choice(["I'm okay. 🤔", "Feeling neutral.", "Nothing special."])

# Engineering Calculator
class EngineeringCalculator:
    def __init__(self):
        pass

    def ohms_law(self, V=None, I=None, R=None):
        if V is None and I is not None and R is not None:
            return I * R
        elif I is None and V is not None and R is not None:
            return V / R
        elif R is None and V is not None and I is not None:
            return V / I
        else:
            return "Please provide exactly two parameters (V, I, or R)."

    def resonance_frequency(self, L, C):
        return 1 / (2 * np.pi * np.sqrt(L * C))

    def complex_power(self, V, I, theta):
        S = V * I * np.exp(1j * theta)
        P = V * I * np.cos(theta)
        Q = V * I * np.sin(theta)
        PF = np.cos(theta)
        return S, P, Q, PF

    def design_op_amp_amplifier(self, gain, R1):
        if gain < 1:
            return "Gain must be greater than or equal to 1."
        R2 = R1 * (gain - 1)
        return {"Resistor R1 (Ω)": R1, "Resistor R2 (Ω)": R2, "Gain": gain}

    def design_low_pass_filter(self, cutoff_frequency, R):
        C = 1 / (2 * np.pi * R * cutoff_frequency)
        return {"Resistor R (Ω)": R, "Capacitor C (F)": C, "Cutoff Frequency (Hz)": cutoff_frequency}

    def design_high_pass_filter(self, cutoff_frequency, C):
        R = 1 / (2 * np.pi * C * cutoff_frequency)
        return {"Resistor R (Ω)": R, "Capacitor C (F)": C, "Cutoff Frequency (Hz)": cutoff_frequency}

    def design_linear_power_supply(self, output_voltage, load_current, ripple_voltage):
        f = 50  # Assuming 50 Hz mains frequency
        C = load_current / (2 * f * ripple_voltage)
        transformer_ratio = output_voltage / 220  # Assuming 220V input
        return {"Capacitor C (F)": C, "Transformer Ratio": transformer_ratio, "Output Voltage (V)": output_voltage,
                "Load Current (A)": load_current, "Ripple Voltage (V)": ripple_voltage}

    def design_relay_circuit(self, relay_voltage, relay_current, transistor_gain):
        V_BE = 0.7
        V_supply = 5
        R_base = (V_supply - V_BE) / (relay_current / transistor_gain)
        return {"Base Resistor R_base (Ω)": R_base, "Relay Voltage (V)": relay_voltage, "Relay Current (A)": relay_current,
                "Transistor Gain": transistor_gain}

# تابع برای تولید شماتیک
def create_schematic(circuit_type, params, output_file="schematic.png"):
    with schemdraw.Drawing(file=output_file) as d:
        if circuit_type == "simple":
            d += (V := elm.SourceV().label(f"{params.get('voltage', '10V')}"))
            d += (R := elm.Resistor().right().label(f"{params.get('resistor', '1kΩ')}"))
            d += (C := elm.Capacitor().right().label(f"{params.get('capacitor', '1µF')}"))
            d += elm.Ground()
            d += elm.Line().left().at(R.start).to(V.start)
            d += elm.Line().left().at(C.end).to(R.end)

        elif circuit_type == "op-amp":
            d += (op := elm.Opamp())
            d += (R1 := elm.Resistor().left().at(op.in2).label(f"{params.get('Resistor R1 (Ω)', 1000)}Ω"))
            d += (R2 := elm.Resistor().up().at(op.out).label(f"{params.get('Resistor R2 (Ω)', 9000)}Ω"))
            d += elm.Line().left().at(R2.end).to(op.in2).length(1)
            d += elm.Ground().at(op.in1)
            d += (V := elm.SourceV().left().at(R1.start).label("Input"))

        elif circuit_type == "low-pass":
            d += (V := elm.SourceV().label(f"{params.get('voltage', '10V')}"))
            d += (R := elm.Resistor().right().label(f"{params.get('Resistor R (Ω)', 1000)}Ω"))
            d += (C := elm.Capacitor().down().label(f"{params.get('Capacitor C (F)', '1µF')}"))
            d += elm.Ground().at(C.end)
            d += elm.Line().left().at(R.start).to(V.start)

        elif circuit_type == "high-pass":
            d += (V := elm.SourceV().label(f"{params.get('voltage', '10V')}"))
            d += (C := elm.Capacitor().right().label(f"{params.get('Capacitor C (F)', '1µF')}"))
            d += (R := elm.Resistor().down().label(f"{params.get('Resistor R (Ω)', 1000)}Ω"))
            d += elm.Ground().at(R.end)
            d += elm.Line().left().at(C.start).to(V.start)

        elif circuit_type == "power-supply":
            d += (V := elm.SourceV().label(f"{params.get('Output Voltage (V)', 12)}V"))
            d += (T := elm.Transformer().right())
            d += (C := elm.Capacitor().right().label(f"{params.get('Capacitor C (F)', '0.1F')}"))
            d += elm.Ground().at(C.end)
            d += elm.Line().left().at(T.start).to(V.start)

        elif circuit_type == "relay":
            d += (V := elm.SourceV().label(f"{params.get('Relay Voltage (V)', 12)}V"))
            d += (R := elm.Resistor().right().label(f"{params.get('Base Resistor R_base (Ω)', 430)}Ω"))
            d += (Q := elm.BjtNpn().right())
            d += (Relay := elm.Relay().up().at(Q.collector).label("Relay"))
            d += elm.Ground().at(Q.emitter)
            d += elm.Line().left().at(R.start).to(V.start)

        elif circuit_type == "low-pass-opamp-power":
            d += (Vin := elm.SourceV().label("Input"))
            d += (R1 := elm.Resistor().right().at(Vin.end).label(f"{params.get('Resistor R (Ω)', 3300)}Ω"))
            d += (C1 := elm.Capacitor().down().at(R1.end).label(f"{params.get('Capacitor C (F)', '96.5nF')}"))
            d += elm.Ground().at(C1.end)
            d += (op := elm.Opamp().right().at(R1.end))
            d += (R2 := elm.Resistor().left().at(op.in2).label(f"{params.get('Resistor R1 (Ω)', 1000)}Ω"))
            d += (R3 := elm.Resistor().up().at(op.out).label(f"{params.get('Resistor R2 (Ω)', 4000)}Ω"))
            d += elm.Line().left().at(R3.end).to(op.in2).length(1)
            d += elm.Ground().at(op.in1)
            d += (Vcc := elm.SourceV().up().at(op.out).label(f"{params.get('Output Voltage (V)', 12)}V"))
            d += elm.Line().right().at(Vcc.end).length(1)

        else:
            return "Circuit type not supported."

    return f"شماتیک برای '{circuit_type}' با موفقیت در '{output_file}' ذخیره شد."

# تابع تولید کد با مدل زبانی
def generate_programming_code(user_input):
    prompt = (
        f"The user requested: {user_input}\n"
        "Generate accurate, complete, and well-structured code in the specified programming language. "
        "If no language is specified, ask the user to clarify. "
        "Include comments for clarity, ensure the code is ready to run, and handle all edge cases. "
        "For complex projects (e.g., neural networks, websites), break it into logical modules."
    )
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# تابع تست و دیباگ کد
def test_and_debug_code(code, language, filename):
    save_code_to_file(code, filename)
    compilers = {
        "python": ["python", filename],
        "go": ["go", "run", filename],
        "c": ["gcc", filename, "-o", "test_output"],
        "cpp": ["g++", filename, "-o", "test_output"],
        "java": ["javac", filename],
        "javascript": ["node", filename],
        "php": ["php", filename],
        "ruby": ["ruby", filename],
    }

    if language not in compilers:
        return f"تست برای {language} هنوز پشتیبانی نمی‌شود. کد ذخیره شد ولی اجرا نشد."

    try:
        result = subprocess.run(compilers[language], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            if language in ["c", "cpp"]:
                exec_result = subprocess.run("./test_output" if os.name != "nt" else "test_output.exe", 
                                            capture_output=True, text=True, timeout=10)
                return f"کد با موفقیت اجرا شد:\n{exec_result.stdout}"
            return f"کد با موفقیت اجرا شد:\n{result.stdout}"
        else:
            error = result.stderr
            debug_prompt = (
                f"The following code in {language} failed with this error:\n{error}\n"
                f"Code:\n{code}\n"
                "Analyze the error, fix the code, and return the corrected version with explanations."
            )
            debug_response = ollama.generate(model="mistral", prompt=debug_prompt)
            fixed_code = debug_response['response']
            save_code_to_file(fixed_code, filename)
            return f"خطا پیدا شد:\n{error}\nکد اصلاح‌شده:\n{fixed_code}"
    except subprocess.TimeoutExpired:
        return "اجرای کد بیش از حد طول کشید."
    except Exception as e:
        return f"خطا در تست کد: {str(e)}"

# تابع ذخیره‌سازی کد
def save_code_to_file(code, filename):
    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write(code)
        return f"کد با موفقیت در {filename} ذخیره شد."
    except Exception as e:
        return f"خطا در ذخیره کد: {str(e)}"

# Generate response
def generate_response(user_input, sentiment, memory, emotion_system, engineering_calculator):
    memory.append({"user": user_input, "sentiment": sentiment})
    with open("memory.json", "w") as f:
        json.dump(memory, f)

    # پاسخ‌های احساسی
    if "i love you" in user_input.lower():
        return random.choice(["I love you too! ❤️", "You make me so happy! 😊", "That means a lot to me!"])
    elif "how are you" in user_input.lower() or "how do you feel" in user_input.lower():
        return emotion_system.get_emotion_response()

    # برنامه‌نویسی
    elif any(x in user_input.lower() for x in ["python", "go", "c++", "c#", "java", "javascript", "php", "ruby", "assembly", "react", "django", "laravel", "html", "code", "programming"]):
        languages = ["python", "go", "c", "cpp", "c#", "java", "javascript", "php", "ruby", "assembly", "react", "django", "laravel", "html"]
        detected_language = None
        for lang in languages:
            if lang in user_input.lower():
                detected_language = lang
                break
        
        if not detected_language:
            return "لطفاً زبان برنامه‌نویسی رو مشخص کن (مثلاً Python، Go، Java)."

        code = generate_programming_code(user_input)
        extensions = {
            "python": "py", "go": "go", "c": "c", "cpp": "cpp", "c#": "cs", "java": "java",
            "javascript": "js", "php": "php", "ruby": "rb", "assembly": "asm", "react": "jsx", "html": "html"
        }
        ext = extensions.get(detected_language, "txt")
        filename = f"generated_code.{ext}"
        save_result = save_code_to_file(code, filename)
        test_result = test_and_debug_code(code, detected_language, filename)
        return f"کد تولید‌شده:\n{code}\n\n{save_result}\n\n{test_result}"

    # مهندسی برق
    elif "calculate" in user_input.lower() or "design" in user_input.lower() or "schematic" in user_input.lower():
        if "ohm's law" in user_input.lower():
            V, I, R = 10, None, 5
            I = engineering_calculator.ohms_law(V=V, R=R)
            return f"Current: {I} A"
        elif "resonance frequency" in user_input.lower():
            L, C = 1e-3, 1e-6
            f0 = engineering_calculator.resonance_frequency(L, C)
            return f"Resonance Frequency: {f0} Hz"
        elif "complex power" in user_input.lower():
            V, I, theta = 220, 5, np.radians(30)
            S, P, Q, PF = engineering_calculator.complex_power(V, I, theta)
            return f"Apparent Power: {S} VA\nActive Power: {P} W\nReactive Power: {Q} VAR\nPower Factor: {PF}"
        elif "op-amp" in user_input.lower() and "low-pass" not in user_input.lower():
            gain, R1 = 5, 1000
            design = engineering_calculator.design_op_amp_amplifier(gain, R1)
            schematic_result = create_schematic("op-amp", design)
            return f"Op-Amp Amplifier Design:\nR1: {design['Resistor R1 (Ω)']} Ω\nR2: {design['Resistor R2 (Ω)']} Ω\nGain: {design['Gain']}\n{schematic_result}"
        elif "low-pass" in user_input.lower() and "op-amp" not in user_input.lower():
            cutoff_frequency, R = 1000, 1000
            design = engineering_calculator.design_low_pass_filter(cutoff_frequency, R)
            schematic_result = create_schematic("low-pass", design)
            return f"Low-Pass Filter Design:\nR: {design['Resistor R (Ω)']} Ω\nC: {design['Capacitor C (F)']} F\nCutoff Frequency: {design['Cutoff Frequency (Hz)']} Hz\n{schematic_result}"
        elif "high-pass" in user_input.lower():
            cutoff_frequency, C = 1000, 1e-6
            design = engineering_calculator.design_high_pass_filter(cutoff_frequency, C)
            schematic_result = create_schematic("high-pass", design)
            return f"High-Pass Filter Design:\nR: {design['Resistor R (Ω)']} Ω\nC: {design['Capacitor C (F)']} F\nCutoff Frequency: {design['Cutoff Frequency (Hz)']} Hz\n{schematic_result}"
        elif "power supply" in user_input.lower():
            output_voltage, load_current, ripple_voltage = 12, 1, 0.1
            design = engineering_calculator.design_linear_power_supply(output_voltage, load_current, ripple_voltage)
            schematic_result = create_schematic("power-supply", design)
            return f"Linear Power Supply Design:\nC: {design['Capacitor C (F)']} F\nTransformer Ratio: {design['Transformer Ratio']}\nOutput Voltage: {design['Output Voltage (V)']} V\nLoad Current: {design['Load Current (A)']} A\nRipple Voltage: {design['Ripple Voltage (V)']} V\n{schematic_result}"
        elif "relay" in user_input.lower():
            relay_voltage, relay_current, transistor_gain = 12, 0.1, 100
            design = engineering_calculator.design_relay_circuit(relay_voltage, relay_current, transistor_gain)
            schematic_result = create_schematic("relay", design)
            return f"Relay Circuit Design:\nR_base: {design['Base Resistor R_base (Ω)']} Ω\nRelay Voltage: {design['Relay Voltage (V)']} V\nRelay Current: {design['Relay Current (A)']} A\nTransistor Gain: {design['Transistor Gain']}\n{schematic_result}"
        elif "low-pass" in user_input.lower() and "op-amp" in user_input.lower():
            cutoff_frequency, R_filter = 500, 3300
            filter_design = engineering_calculator.design_low_pass_filter(cutoff_frequency, R_filter)
            gain, R1_opamp = 5, 1000
            opamp_design = engineering_calculator.design_op_amp_amplifier(gain, R1_opamp)
            power_design = engineering_calculator.design_linear_power_supply(12, 1, 0.1)
            params = {
                "Resistor R (Ω)": R_filter,
                "Capacitor C (F)": filter_design["Capacitor C (F)"],
                "Resistor R1 (Ω)": R1_opamp,
                "Resistor R2 (Ω)": opamp_design["Resistor R2 (Ω)"],
                "Output Voltage (V)": 12
            }
            schematic_result = create_schematic("low-pass-opamp-power", params)
            return (
                f"Low-Pass Filter + Op-Amp Design:\n"
                f"Filter Resistor: {filter_design['Resistor R (Ω)']} Ω\n"
                f"Filter Capacitor: {filter_design['Capacitor C (F)']} F\n"
                f"Cutoff Frequency: {filter_design['Cutoff Frequency (Hz)']} Hz\n"
                f"Op-Amp R1: {opamp_design['Resistor R1 (Ω)']} Ω\n"
                f"Op-Amp R2: {opamp_design['Resistor R2 (Ω)']} Ω\n"
                f"Gain: {opamp_design['Gain']}\n"
                f"Power Supply: 12V\n"
                f"{schematic_result}"
            )
        elif "schematic" in user_input.lower():
            params = {"voltage": "10V", "resistor": "1kΩ", "capacitor": "1µF"}
            return create_schematic("simple", params)
        else:
            return "Engineering request not recognized."

    # پاسخ پیش‌فرض
    else:
        prompt = f"The user is feeling {sentiment} and said: {user_input}\nRespond in a {emotion_system.current_emotion} manner (keep it short and human-like):"
        response = ollama.generate(model="mistral", prompt=prompt)
        return response['response']

# تابع تبدیل متن به گفتار
def text_to_speech(text):
    try:
        if os.path.exists("response.mp3"):
            os.remove("response.mp3")
        tts = gTTS(text=text, lang='en')
        tts.save("response.mp3")
        pygame.mixer.init()
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()
        pygame.mixer.music.load("response.mp3")
        time.sleep(0.5)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except Exception as e:
        print(f"gTTS failed: {e}. Switching to pyttsx3...")
        engine.say(text)
        engine.runAndWait()

# Thread for capturing image
class CaptureImageThread(QThread):
    image_captured = pyqtSignal(str)

    def run(self):
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.image_captured.emit("Error: Could not open camera.")
            return
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
        cap.set(cv2.CAP_PROP_FPS, 30)
        ret, frame = cap.read()
        if ret:
            image_path = "captured_image.png"
            cv2.imwrite(image_path, frame, [cv2.IMWRITE_PNG_COMPRESSION, 0])
            self.image_captured.emit(image_path)
        cap.release()

# Thread for speech recognition
class SpeechRecognitionThread(QThread):
    speech_text = pyqtSignal(str)
    activation_signal = pyqtSignal()

    def run(self):
        model_path = r"C:\Users\Mohamad\Desktop\chatbot\vosk-model-small-en-us-0.15"
        if not os.path.exists(model_path):
            self.speech_text.emit("Error: Vosk model not found.")
            return
        model = vosk.Model(model_path)
        samplerate = 16000
        device = 1
        q = queue.Queue()

        def callback(indata, frames, time, status):
            if status:
                print(status, file=sys.stderr)
            q.put(bytes(indata))

        try:
            with sd.RawInputStream(samplerate=samplerate, blocksize=8000, device=device,
                                  dtype='int16', channels=1, callback=callback):
                rec = vosk.KaldiRecognizer(model, samplerate)
                print("Listening for activation word...")
                while True:
                    data = q.get()
                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result())
                        text = result['text'].lower()
                        if "zero" in text:
                            self.activation_signal.emit()
                            print("Activation word detected! Listening for your command...")
                            while True:
                                data = q.get()
                                if rec.AcceptWaveform(data):
                                    result = json.loads(rec.Result())
                                    command = result['text']
                                    if command.strip():
                                        self.speech_text.emit(command)
                                        break
        except Exception as e:
            self.speech_text.emit(f"Error: {str(e)}")

# Main chatbot GUI
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.avatar = Avatar()
        self.memory = self.load_memory()
        self.emotion_system = EmotionSystem()
        self.engineering_calculator = EngineeringCalculator()
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.avatar.draw)
        self.timer.start(1000)
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.activation_signal.connect(self.activate_bot)
        self.voice_thread.start()

    def load_memory(self):
        if os.path.exists("memory.json"):
            with open("memory.json", "r") as f:
                return json.load(f)
        return []

    def initUI(self):
        self.setWindowTitle("Zero - Your Wise Companion")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("""
            QWidget { background-color: #2E3440; color: #D8DEE9; }
            QTextEdit { background-color: #3B4252; color: #ECEFF4; border: 1px solid #4C566A; border-radius: 5px; padding: 10px; font-size: 14px; }
            QLineEdit { background-color: #3B4252; color: #ECEFF4; border: 1px solid #4C566A; border-radius: 5px; padding: 10px; font-size: 14px; }
            QPushButton { background-color: #5E81AC; color: #ECEFF4; border: none; border-radius: 5px; padding: 10px; font-size: 14px; }
            QPushButton:hover { background-color: #81A1C1; }
        """)
        layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)
        input_layout = QHBoxLayout()
        self.user_input = QLineEdit()
        self.user_input.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.user_input)
        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        input_layout.addWidget(send_button)
        voice_button = QPushButton("🎤")
        voice_button.clicked.connect(self.start_voice_input)
        input_layout.addWidget(voice_button)
        capture_button = QPushButton("📷")
        capture_button.clicked.connect(self.capture_image)
        input_layout.addWidget(capture_button)
        layout.addLayout(input_layout)
        self.setLayout(layout)
        self.chat_display.append("Zero is waiting for the activation word 'zero'...\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

    def send_message(self):
        user_message = self.user_input.text()
        if not user_message.strip():
            return
        sentiment, color = analyze_sentiment(user_message)
        self.chat_display.append(f"You: {user_message}")
        self.chat_display.setTextColor(color)
        self.user_input.clear()
        self.emotion_system.update_emotion(sentiment)
        QTimer.singleShot(1000, lambda: self.show_response(user_message, sentiment))

    def show_response(self, user_message, sentiment):
        response = generate_response(user_message, sentiment, self.memory, self.emotion_system, self.engineering_calculator)
        self.chat_display.append(f"Zero: {response}\n")
        text_to_speech(response)
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)
        self.avatar.update_expression(self.emotion_system.current_emotion)

    def start_voice_input(self):
        self.voice_thread = SpeechRecognitionThread()
        self.voice_thread.speech_text.connect(self.handle_voice_input)
        self.voice_thread.start()

    def handle_voice_input(self, text):
        self.user_input.setText(text)
        self.send_message()

    def activate_bot(self):
        self.chat_display.append("Zero activated! How can I help you?\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

    def capture_image(self):
        self.capture_thread = CaptureImageThread()
        self.capture_thread.image_captured.connect(self.handle_captured_image)
        self.capture_thread.start()

    def handle_captured_image(self, image_path):
        self.chat_display.append(f"Image captured: {image_path}\n")
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    chatbot = ChatbotGUI()
    chatbot.show()
    pygame_thread = pygame.threads.Thread(target=chatbot.avatar.run)
    pygame_thread.start()
    sys.exit(app.exec())